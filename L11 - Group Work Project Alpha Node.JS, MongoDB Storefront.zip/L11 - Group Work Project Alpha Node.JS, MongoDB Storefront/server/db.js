/* 
===============================================================
IST 256 – L11: NodeJS + MongoDB Storefront Backend
Group Members:
- Isaiah Ukih — MongoDB Connection
- Logan VonGuden — Products Collection Design
- Alex Tysak — Shopping Cart API Routes
- Daniel Weeks — Shipping/Billing & Returns API Integration
===============================================================
*/

const { MongoClient } = require("mongodb");

const uri = "mongodb://127.0.0.1:27017";   // Local MongoDB
const client = new MongoClient(uri);

let db = null;

async function connectDB() {
    try {
        await client.connect();
        console.log("✅ Connected to MongoDB successfully!");

        db = client.db("AlphaStorefront"); // database name
        return db;

    } catch (err) {
        console.error("❌ MongoDB Connection Error:", err);
    }
}

function getDB() {
    if (!db) throw Error("Database not connected!");
    return db;
}

module.exports = { connectDB, getDB };
