const { Schema, model } = require("mongoose");

const CartSchema = new Schema({
  shopperEmail: String,
  items: [{ productName: String, sku: String, qty: Number, price: Number }],
  updatedAt: { type: Date, default: Date.now }
});

module.exports = model("ShoppingCart", CartSchema);
