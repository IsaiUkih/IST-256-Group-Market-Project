const { Schema, model } = require("mongoose");

const ReturnItemSchema = new Schema({
  shopperEmail: String,
  items: [{ productName: String, sku: String, price: Number, reason: String, condition: String }],
  createdAt: { type: Date, default: Date.now }
});

module.exports = model("ReturnItem", ReturnItemSchema);
