const { Schema, model } = require("mongoose");

const ProductSchema = new Schema({
  productName: String,
  sku: String,
  price: Number,
  stock: Number,
  category: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = model("Product", ProductSchema);
