const { Schema, model } = require("mongoose");

const ShipBillSchema = new Schema({
  fullname: String,
  email: String,
  address: String,
  city: String,
  state: String,
  zip: String,
  cardLast4: String,
  expiry: String,
  shippingMethod: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = model("ShippingBilling", ShipBillSchema);
