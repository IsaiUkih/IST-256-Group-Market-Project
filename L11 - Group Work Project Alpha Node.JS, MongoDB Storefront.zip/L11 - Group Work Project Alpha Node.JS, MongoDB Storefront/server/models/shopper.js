const { Schema, model } = require("mongoose");

const ShopperSchema = new Schema({
  fullname: String,
  email: { type: String, required: true, index: true },
  address: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = model("Shopper", ShopperSchema);
