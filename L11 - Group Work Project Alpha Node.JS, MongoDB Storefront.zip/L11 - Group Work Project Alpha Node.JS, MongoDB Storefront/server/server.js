/* 
===============================================================
IST 256 – L11 NodeJS + MongoDB REST API
Group Members:
- Isaiah, Logan, Alex, Daniel
===============================================================
*/

const express = require("express");
const cors = require("cors");
const { connectDB, getDB } = require("./db");

const app = express();
app.use(cors());
app.use(express.json());

// Connect to MongoDB first
connectDB().then(() => {
    const db = getDB();

    /* =============================================
       1. SHOPPER COLLECTION  (Isaiah)
    ============================================= */
    app.post("/api/shopper", async (req, res) => {
        const result = await db.collection("shopper").insertOne(req.body);
        res.send({ status: "ok", inserted_id: result.insertedId });
    });

    /* =============================================
       2. PRODUCTS COLLECTION  (Logan)
    ============================================= */
    app.post("/api/products", async (req, res) => {
        const result = await db.collection("products").insertOne(req.body);
        res.send({ status: "ok", inserted_id: result.insertedId });
    });

    /* =============================================
       3. SHOPPING CART COLLECTION  (Alex)
    ============================================= */
    app.post("/api/cart", async (req, res) => {
        const result = await db.collection("shopping_cart").insertOne(req.body);
        res.send({ status: "ok", inserted_id: result.insertedId });
    });

    /* =============================================
       4. SHIPPING/BILLING COLLECTION  (Daniel)
    ============================================= */
    app.post("/api/billing", async (req, res) => {
        const result = await db.collection("shipping_billing").insertOne(req.body);
        res.send({ status: "ok", inserted_id: result.insertedId });
    });

    /* =============================================
       5. RETURNS COLLECTION  (Isaiah + Daniel)
    ============================================= */
    app.post("/api/returns", async (req, res) => {
        const result = await db.collection("returns").insertOne(req.body);
        res.send({ status: "ok", inserted_id: result.insertedId });
    });

    // Start Server
    app.listen(5000, () => {
        console.log("🚀 NodeJS server running on http://localhost:5000");
    });
});
