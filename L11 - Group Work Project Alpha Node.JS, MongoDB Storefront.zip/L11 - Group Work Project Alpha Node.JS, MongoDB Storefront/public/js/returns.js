/* 
Returns Frontend JS (AJAX + jQuery search)
Authors: Isaiah Ukih, Logan VonGuden, Alexander Tysak, Daniel Weeks
*/
$(function() {
  // sample product list could be loaded via AJAX; here's a local sample for demo
  const sampleProducts = [
    { productName: "Wireless Mouse", price: 29.99, sku: "WM001" },
    { productName: "Bluetooth Headphones", price: 59.99, sku: "BH002" }
  ];

  // Render product cards to #product-results (ensure markup exists)
  const $results = $("#product-results");
  if ($results.length) {
    $results.empty();
    sampleProducts.forEach((p, idx) => {
      const $card = $(`
        <div class="product-item card p-3 mb-3" data-name="${p.productName.toLowerCase()}">
          <div class="d-flex justify-content-between">
            <div>
              <h5>${p.productName}</h5>
              <p class="mb-1">$${p.price.toFixed(2)}</p>
              <small>SKU: ${p.sku}</small>
            </div>
            <div style="min-width:220px;">
              <label>Reason:</label>
              <input class="form-control reason-input mb-2" data-sku="${p.sku}" placeholder="Reason for return">
              <label>Condition:</label>
              <select class="form-select condition-select" data-sku="${p.sku}">
                <option>New</option><option>Used</option><option>Damaged</option>
              </select>
            </div>
          </div>
        </div>
      `);
      $results.append($card);
    });
  }

  // search filter
  $("#searchProduct").on("input", function() {
    const val = $(this).val().toLowerCase();
    $(".product-item").each(function() {
      const name = $(this).data("name") || "";
      $(this).toggle(name.indexOf(val) > -1);
    });
  });

  // submit returns
  $("#returnForm").on("submit", function(e) {
    e.preventDefault();

    const items = [];
    $(".product-item").each(function() {
      const sku = $(this).find(".reason-input").data("sku");
      const reason = $(this).find(".reason-input").val() || "";
      const condition = $(this).find(".condition-select").val();
      const name = $(this).find("h5").text();
      const priceText = $(this).find("p").first().text().replace("$","").trim();
      const price = parseFloat(priceText) || 0;

      if (reason.trim()) {
        items.push({ productName: name, sku, price, reason, condition });
      }
    });

    if (items.length === 0) {
      alert("Please provide a reason for at least one product to return.");
      return;
    }

    $.ajax({
      url: "/api/returns",
      method: "POST",
      contentType: "application/json",
      data: JSON.stringify({ shopperEmail: $("#returnEmail").val() || "", items }),
      success: function(res) {
        alert("Return request submitted. ID: " + (res.insertedId || res._id));
        $("#returnsResult").text(JSON.stringify(res, null, 2)).show();
      },
      error: function(xhr) {
        alert("Error submitting return request.");
        console.error(xhr);
      }
    });
  });
});
