/* 
Billing Frontend JS (AJAX)
Authors: Isaiah Ukih, Logan VonGuden, Alexander Tysak, Daniel Weeks
Uses jQuery for AJAX calls to Node/Mongo backend
*/
$(function() {
  $("#billingForm").on("submit", function(e) {
    e.preventDefault();

    // Read form values (use IDs or inputs in your billing.html)
    const payload = {
      fullname: $("#fullname").val() || $("#fullName").val(), // match your markup
      email: $("#email").val() || $("#billingEmail").val(),
      address: $("#address").val(),
      city: $("#city").val(),
      state: $("#state").val(),
      zip: $("#zip").val(),
      // ---- PAYMENT: do not send real card numbers in assignments or screenshots ----
      cardLast4: ( $("#cardNumber").val() || "" ).slice(-4), // only last 4 digits
      expiry: $("#expiry").val()
    };

    // basic client validation (you can expand)
    if (!payload.fullname || !payload.address) {
      alert("Please fill in required fields (name & address).");
      return;
    }

    // AJAX POST to backend
    $.ajax({
      url: "/api/shippingBilling",
      method: "POST",
      contentType: "application/json",
      data: JSON.stringify(payload),
      success: function(res) {
        alert("Billing details saved. Server ID: " + (res.insertedId || res._id || ""));
        console.log("Server response:", res);
        // show summary on page (optional)
        $("#billingResult").text(JSON.stringify(res, null, 2)).show();
      },
      error: function(xhr) {
        alert("Error saving billing info.");
        console.error(xhr);
      }
    });
  });
});
